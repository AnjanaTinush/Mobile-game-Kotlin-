package com.example.game

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class item_question_row : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_question_row)
    }
}